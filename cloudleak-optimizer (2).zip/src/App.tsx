import { useState, useMemo } from 'react';
import { 
  Cloud, 
  ShieldAlert, 
  Settings2, 
  Zap, 
  Lock, 
  Activity, 
  Terminal,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import Markdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";

// --- Types ---

type CloudProvider = 'aws' | 'gcp' | 'azure' | 'private';

interface DataShard {
  id: string;
  provider: CloudProvider;
  latency: number;
  riskScore: number;
  size: number;
}

// --- Constants ---

const PROVIDERS: { id: CloudProvider; name: string; color: string }[] = [
  { id: 'aws', name: 'AWS us-east-1', color: '#FF9900' },
  { id: 'gcp', name: 'GCP europe-west1', color: '#4285F4' },
  { id: 'azure', name: 'Azure East US', color: '#0078D4' },
  { id: 'private', name: 'On-Prem / Private', color: '#10B981' },
];

// --- Mock Data ---

const INITIAL_SHARDS: DataShard[] = [
  { id: 's-001', provider: 'aws', latency: 45, riskScore: 0.12, size: 256 },
  { id: 's-002', provider: 'gcp', latency: 52, riskScore: 0.08, size: 256 },
  { id: 's-003', provider: 'azure', latency: 68, riskScore: 0.15, size: 256 },
  { id: 's-004', provider: 'private', latency: 12, riskScore: 0.02, size: 256 },
];

// --- Components ---

const SidebarItem = ({ active, label, onClick }: any) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-all rounded-lg ${
      active 
        ? 'bg-slate-100 text-slate-900 font-semibold' 
        : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
    }`}
  >
    <div className={`w-2 h-2 rounded-full transition-colors ${active ? 'bg-slate-900' : 'bg-slate-300'}`} />
    <span className="text-sm tracking-tight">{label}</span>
  </button>
);

const MetricCard = ({ label, value, trend, unit }: any) => (
  <div className="tech-card">
    <div className="flex justify-between items-start mb-1">
      <span className="tech-label">{label}</span>
    </div>
    <div className="flex items-baseline gap-1">
      <span className="tech-value">{value}</span>
      {unit && <span className="text-sm text-slate-300 font-medium ml-1">{unit}</span>}
      {trend !== undefined && (
        <span className={`ml-3 text-[11px] font-bold px-2 py-0.5 rounded-full ${trend > 0 ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-600'}`}>
          {trend > 0 ? '+' : ''}{trend}%
        </span>
      )}
    </div>
  </div>
);

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState<'topology' | 'optimizer' | 'auditor'>('topology');
  const [shards] = useState<DataShard[]>(INITIAL_SHARDS);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditResponse, setAuditResponse] = useState<string | null>(null);
  const [configInput, setConfigInput] = useState('');

  const leakageScore = useMemo(() => {
    const totalRisk = shards.reduce((acc, s) => acc + s.riskScore, 0);
    return Math.round(totalRisk / shards.length * 100);
  }, [shards]);

  const auditConfig = async () => {
    if (!configInput) return;
    setAuditLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const prompt = `
        You are a Cloud Security Expert. Analyze the following multicloud storage configuration for potential "information leakage" or security risks. 
        Provide a structured response in Markdown.
        Include:
        1. A "Leakage Risk Score" (0-100).
        2. Top 3 Vulnerabilities.
        3. Optimization Strategy to minimize leakage using data dispersion or fragmentation.
        
        Config:
        ${configInput}
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      setAuditResponse(response.text || "No response received from agent.");
    } catch (e: any) {
      console.error(e);
      setAuditResponse("Error analyzing configuration. Please check if GEMINI_API_KEY is set in settings.\n\nDetails: " + (e.message || "Unknown error"));
    } finally {
      setAuditLoading(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden selection:bg-slate-900 selection:text-white bg-slate-50 text-slate-900 font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0">
        <div className="p-8 pb-10">
          <h1 className="text-xs font-bold tracking-widest text-slate-400 uppercase mb-1 flex items-center gap-2">
            <ShieldCheck size={14} /> LEAKSHIELD
          </h1>
          <div className="text-lg font-semibold tracking-tight">Core Analysis</div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          <SidebarItem 
            active={activeTab === 'topology'} 
            label="Dashboard" 
            onClick={() => setActiveTab('topology')} 
          />
          <SidebarItem 
            active={activeTab === 'optimizer'} 
            label="Multicloud Map" 
            onClick={() => setActiveTab('optimizer')} 
          />
          <SidebarItem 
            active={activeTab === 'auditor'} 
            label="Storage Audit" 
            onClick={() => setActiveTab('auditor')} 
          />
        </nav>

        <div className="p-8 border-t border-slate-100 mt-auto">
          <div className="text-[10px] text-slate-400 uppercase tracking-tighter mb-4 font-bold flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Status: Active
          </div>
          <div className="flex space-x-2">
            {PROVIDERS.slice(0, 3).map(p => (
              <div 
                key={p.id}
                title={p.name}
                className="w-7 h-7 flex items-center justify-center rounded text-[9px] font-bold"
                style={{ backgroundColor: `${p.color}15`, color: p.color }}
              >
                {p.id.slice(0, 3).toUpperCase()}
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-20 bg-white border-b border-slate-200 flex items-center px-10 justify-between shrink-0">
          <div className="flex flex-col">
            <span className="text-xs text-slate-400 font-medium">Project Registry</span>
            <span className="text-sm font-semibold text-slate-700">mercury-infrastructure / prod-v4</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="tech-button">Export Report</button>
            <button className="tech-button-primary">New Scan</button>
          </div>
        </header>

        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-10 space-y-8 pb-10">
          <AnimatePresence mode="wait">
            {activeTab === 'topology' && (
              <motion.div 
                key="topology"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <MetricCard label="Leak Score" value={leakageScore} unit="/100" />
                  <MetricCard label="Cloud Objects" value="1.4k" unit="" />
                  <MetricCard label="Latency Score" value="24" unit="ms" trend={5} />
                  <MetricCard label="Remediation" value="22" unit="%" />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Distribution Map */}
                  <div className="lg:col-span-2 tech-card flex flex-col min-h-[400px]">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-xs font-semibold text-slate-500 uppercase">Multicloud Risk Map</span>
                      <div className="flex gap-4">
                        {PROVIDERS.map(p => (
                          <div key={p.id} className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: p.color }} />
                            <span className="text-[10px] font-bold text-slate-400 uppercase">{p.id}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex-1 border border-slate-100 rounded-lg bg-slate-50/50 relative flex items-center justify-center p-8">
                      <svg className="w-full h-full">
                         <line x1="30%" y1="30%" x2="70%" y2="30%" stroke="#E2E8F0" strokeDasharray="4 4" />
                         <line x1="30%" y1="30%" x2="50%" y2="70%" stroke="#E2E8F0" strokeDasharray="4 4" />
                         <line x1="70%" y1="30%" x2="50%" y2="70%" stroke="#E2E8F0" strokeDasharray="4 4" />

                         {PROVIDERS.map((p, idx) => {
                            const x = [30, 70, 50, 50][idx];
                            const y = [30, 30, 70, 50][idx];
                            return (
                              <g key={p.id}>
                                <motion.circle 
                                  cx={`${x}%`} 
                                  cy={`${y}%`} 
                                  r="20" 
                                  fill="white" 
                                  stroke={p.color} 
                                  strokeWidth="2"
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  transition={{ delay: idx * 0.1 }}
                                />
                                <text x={`${x}%`} y={`${y}%`} textAnchor="middle" dy="4" fontSize="9" fill={p.color} className="font-bold opacity-80">
                                  {p.id.toUpperCase()}
                                </text>
                              </g>
                            )
                         })}
                      </svg>
                    </div>
                  </div>

                  {/* Realtime Risk Stats */}
                  <div className="tech-card bg-slate-900 text-white border-transparent">
                    <div className="text-[10px] text-slate-400 uppercase font-bold mb-4">Risk Distribution</div>
                    <div className="flex justify-between items-end h-32 space-x-2 mt-8">
                      {PROVIDERS.map((p, idx) => {
                        const heights = ['60%', '90%', '40%', '75%'];
                        return (
                          <div key={p.id} className="w-full bg-slate-800 rounded-t relative group" style={{ height: heights[idx] }}>
                            <div className="absolute inset-0 bg-slate-700 opacity-0 group-hover:opacity-100 transition-opacity rounded-t" />
                            <div className="absolute -top-5 left-0 right-0 text-[8px] text-center text-slate-500 font-bold">{p.id.toUpperCase()}</div>
                          </div>
                        )
                      })}
                    </div>
                    
                    <div className="mt-12 space-y-4">
                       <div className="text-[11px] font-bold text-slate-400 uppercase border-b border-slate-800 pb-2">Analysis Engine</div>
                       <p className="text-xs text-slate-500 leading-relaxed italic">
                         Multivariate dispersion active. Entropy scanning complete. No unauthorized access paths detected in last cycle.
                       </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'optimizer' && (
              <motion.div 
                key="optimizer"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 lg:grid-cols-3 gap-8"
              >
                <div className="lg:col-span-1 space-y-6">
                  <div className="tech-card">
                    <h3 className="text-xs font-bold text-slate-900 uppercase mb-4">Optimization Parameters</h3>
                    <div className="space-y-6">
                       <div className="space-y-3">
                         <div className="flex justify-between items-center text-[11px] font-bold uppercase">
                           <span className="text-slate-400">Dispersion Ratio</span>
                           <span className="text-slate-900 font-mono">24/k</span>
                         </div>
                         <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                           <div className="w-2/3 h-full bg-slate-900" />
                         </div>
                       </div>
                       
                       <div className="space-y-3">
                         <div className="flex justify-between items-center text-[11px] font-bold uppercase">
                           <span className="text-slate-400">Entropy Scale</span>
                           <span className="text-slate-900 font-mono">0.82</span>
                         </div>
                         <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                           <div className="w-[82%] h-full bg-slate-900" />
                         </div>
                       </div>
                    </div>
                    <ul className="mt-8 space-y-4">
                      <li className="flex items-start space-x-3">
                        <div className="w-4 h-4 mt-0.5 rounded-full border-2 border-slate-200 flex-shrink-0" />
                        <span className="text-xs text-slate-500">Migrate keys to <strong>Vault</strong>.</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <div className="w-4 h-4 mt-0.5 rounded-full border-2 border-slate-900 bg-slate-900" />
                        <span className="text-xs text-slate-500 font-medium">Implement <strong>IAM Roles</strong>.</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="lg:col-span-2 tech-card">
                   <div className="px-0 py-0 border-b border-slate-100 flex justify-between items-center mb-6">
                     <span className="text-xs font-bold text-slate-400 uppercase">Multicloud Topology Graph</span>
                     <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-bold">LEGACY MODE</span>
                   </div>
                   <div className="h-[300px] w-full flex items-center justify-center text-slate-200">
                     <Cloud size={120} className="opacity-10" />
                   </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'auditor' && (
              <motion.div 
                key="auditor"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 lg:grid-cols-5 gap-8"
              >
                <div className="lg:col-span-2 space-y-6 flex flex-col">
                  <div className="tech-card flex-1 flex flex-col p-0 overflow-hidden">
                    <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-white sticky top-0 z-10">
                      <span className="text-xs font-bold text-slate-400 uppercase">Input Registry Configuration</span>
                    </div>
                    <textarea 
                      className="flex-1 p-6 font-mono text-sm focus:outline-none resize-none bg-white text-slate-600 placeholder:text-slate-200"
                      placeholder={`// Paste your cloud config here...\n\n{"storage": {"acl": "public"}}`}
                      value={configInput}
                      onChange={(e) => setConfigInput(e.target.value)}
                    />
                    <div className="p-6 bg-slate-50 border-t border-slate-100">
                      <button 
                        onClick={auditConfig}
                        disabled={auditLoading}
                        className="w-full tech-button-primary disabled:bg-slate-300"
                      >
                        {auditLoading ? 'ANALYZING...' : 'RUN SECURITY SCAN'}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-3 flex flex-col space-y-6">
                   <div className="bg-white rounded-xl border border-slate-200 flex flex-col shadow-sm overflow-hidden flex-1">
                      <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-400 uppercase">AI Security Auditor Output</span>
                        {auditResponse && <span className="text-[10px] bg-red-50 text-red-600 px-2 py-1 rounded font-bold uppercase tracking-wider">Audit Complete</span>}
                      </div>
                      <div className="p-10 prose prose-slate prose-sm max-w-none prose-headings:font-semibold prose-headings:tracking-tight prose-strong:text-slate-900 prose-p:text-slate-500">
                        {auditResponse ? (
                          <Markdown>{auditResponse}</Markdown>
                        ) : (
                          <div className="flex flex-col items-center justify-center p-12 text-slate-300 opacity-50 space-y-4">
                             <Lock size={48} strokeWidth={1} />
                             <p className="font-medium text-sm">Awaiting configuration payload for metadata analysis</p>
                          </div>
                        )}
                      </div>
                   </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
